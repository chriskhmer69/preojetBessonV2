﻿CREATE TABLE Sheet1(Response VARCHAR(10),Exception VARCHAR(10));
